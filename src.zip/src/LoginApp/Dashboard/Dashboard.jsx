import React from 'react'
import { Outlet } from 'react-router-dom'

export default function Dashboard() {
  return (
    <div>

        <div>HELLO FUSE</div>
        <Outlet/>
    </div>
  )
}
