import React from 'react'

export default function Modal() {
  return (
    <div>
        
    </div>
  )
}
