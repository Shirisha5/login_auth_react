import React, { useState, useEffect } from "react";
import loginImg from "../../Assets/login_svg.svg";
import fuse from "../../Assets/flash.png";

export default function LoginScreen({ setToken }) {
  const [username, setUsername] = useState();
  const [password, setPassword] = useState();
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState("password");

  const loginUser = async (credentials) => {
    await fetch("http://restapi.adequateshop.com/api/authaccount/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(credentials),
    })
      .then((response) => response.json())
      .then((data) =>
        data.message === "success" ? setToken(data.data.Token) : ""
      );
  };

  const togglePassword = () => {
    if (showPassword === "password") {
      setShowPassword("text");
      return;
    }
    setShowPassword("password");
  };

  const validate = async () => {
    let errors = {};
    let isValid = true;
    if (!username) {
      console.log("true1");
      isValid = false;
      errors["username"] = "Please enter your email Address.";
    }
    if (typeof username !== "undefined") {
      console.log("true2");
      var pattern = new RegExp(
        /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
      );
      if (!pattern.test(username)) {
        isValid = false;
        errors["username"] = "Please enter valid email address.";
      }
    }
    if (!password) {
      console.log("true3");
      isValid = false;
      errors["password"] = "Please enter your password.";
    }

    if (typeof password !== "undefined") {
      console.log("true4");
      if (password.length < 6) {
        isValid = false;
        errors["password"] = "Please add at least 6 charachter.";
      }
    }

    console.log(errors);

    await setErrors(errors);

    return isValid;
  };

  const submitHandler = async (e) => {
    e.preventDefault();
    await validate();

    if (validate()) {
      let loginData = {
        // "email": "ReactDev@gmail.com",
        // "password": 456789
        email: username,
        password: password,
      };
      await loginUser(loginData);
    }

    //
  };

  return (
    <div className="login_full_page">
      <div className="row login_page_wrapper">
        <div className="column login_content_container">
            <div className="login_creator">
          <div className="logo_container">
            <div className="brand_logo">
              <img src={fuse} />
            </div>
            <div className="brand_name">TINKER</div>
          </div>

          <div className="logo_welcome">
            <div className="logo_welcome_title">Welcome back!</div>
            <div className="logo_welcome_subtitle">
              Please login to your account.
            </div>
          </div>
          <form onSubmit={submitHandler}>
            <div className="login_form">
              <div className="login_component">
                <div className="input_label">Username/Email Address</div>
                <input
                  type="text"
                  className="input_text"
                  onChange={(e) => setUsername(e.target.value)}
                />
                <div className="error_title">{errors.username}</div>
              </div>

              <div className="login_component">
                <div className="input_label">Password</div>
                <div className="input_container">
                  <input
                    type={showPassword}
                    className="input_text"
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <span
                    className="show_hide_text"
                    onClick={() => togglePassword()}
                  >
                    {showPassword === "password"
                      ? "Show"
                      : showPassword === "text"
                      ? "Hide"
                      : ""}
                  </span>
                </div>
                <div className="error_title">{errors.password}</div>
              </div>
            </div>
            <div className="login_button_wrapper">
              <button type="submit" className="login_button">
                Login to Tinker
              </button>
            </div>
          </form>
          </div>
        </div>
        <div className="column login_image_container">
          <div></div>
          <div className="login_img">
            <img src={loginImg} className="img_value" />
          </div>
        </div>
      </div>
    </div>
  );
}
