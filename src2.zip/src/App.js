import './App.css';
import React,{useState} from 'react';
import LoginScreen from './LoginApp/LoginScreen/LoginScreen';
import './Styles/Styles.css';
import { Route,Routes } from 'react-router-dom';
import Dashboard from './LoginApp/Dashboard/Dashboard';

function App() {
  const [token, setToken] = useState();

  if(!token) {
    return <LoginScreen setToken={setToken} />
  }
  return (
    <div className="app">
      <Routes>
        <Route path="/" element={<Dashboard />}>
          
        </Route>
      </Routes>
    </div>
  );
}

export default App;
